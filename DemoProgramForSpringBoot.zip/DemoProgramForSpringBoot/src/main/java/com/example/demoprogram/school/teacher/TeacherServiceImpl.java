package com.example.demoprogram.school.teacher;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class TeacherServiceImpl implements TeacherService{

	
	@Autowired
	TeacherRepository teacherRepository;
	
	
	@Override
	public List<Teacher> getAllTeachers() {
		return teacherRepository.findAll();
	}

	@Override
	public Teacher createTeacher(Teacher teacher) {
		
		return teacherRepository.save(teacher);
	}

	@Override
	public List<Teacher> getAllTeachersByStatus(String status) {
		return teacherRepository.findAllTeachersByStatus(status);
	}

}

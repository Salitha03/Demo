package com.example.demoprogram.school.student;

import java.util.List;

public interface StudentService {

	List<Student> getAllStudents();

	Student createStudent(Student student);
	
	List<Student> findAllStudents();
}

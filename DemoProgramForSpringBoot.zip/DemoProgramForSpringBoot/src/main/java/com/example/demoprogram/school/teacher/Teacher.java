package com.example.demoprogram.school.teacher;

import java.util.HashSet;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import com.example.demoprogram.school.subject.Subject;
import com.fasterxml.jackson.annotation.JsonIgnore;

@Entity
@Table
/**
 * @author Salitha
 * Teacher entity 
 * Relationships:
 * 1)  One teacher can teach multiple subjects. (One to Many relationship)
 * 
 */
public class Teacher {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private long id;
	
	private String name;
	
	private String status;
	
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public long getId() {
		return id;
	}
	public void setId(long id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	
	//Bi-directional mapping
	@JsonIgnore
	@OneToMany(targetEntity=Subject.class,mappedBy = "teacher",fetch = FetchType.LAZY, cascade = CascadeType.ALL)
	private Set<Subject> subjects = new HashSet<>();
	public Set<Subject> getSubjects() {
		return subjects;
	}
	
	
	
}

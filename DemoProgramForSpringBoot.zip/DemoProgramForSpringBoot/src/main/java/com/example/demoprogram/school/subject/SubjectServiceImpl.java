package com.example.demoprogram.school.subject;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demoprogram.school.student.Student;
import com.example.demoprogram.school.student.StudentRepository;
import com.example.demoprogram.school.teacher.Teacher;
import com.example.demoprogram.school.teacher.TeacherRepository;

@Service
public class SubjectServiceImpl implements SubjectService{

	
	@Autowired
	SubjectRepository subjectRepository;
	
	@Autowired
	StudentRepository studentRepository;
	
	@Autowired
	TeacherRepository teacherRepository;
	
	@Override
	public List<Subject> getAllSubjects() {
		return subjectRepository.findAll();
	}

	@Override
	public Subject createSubject(Subject subject) {
		return subjectRepository.save(subject);
	}

	@Override
	public Subject enrollStudentToSubject(long subjectId, long studentId) {
		Subject subject=subjectRepository.findById(subjectId).get();
		Student student= studentRepository.findById(studentId).get();
		subject.getEnrolledStudents().add(student); //add students to subject
		return subjectRepository.save(subject);

	}

	@Override
	public Subject assignTeacherToSubject(long subjectId, long teacherId) {
		Subject subject=subjectRepository.findById(subjectId).get();
		Teacher teacher= teacherRepository.findById(teacherId).get();
		subject.setTeacher(teacher);//add teacher to subject
	    return subjectRepository.save(subject);
	}

}

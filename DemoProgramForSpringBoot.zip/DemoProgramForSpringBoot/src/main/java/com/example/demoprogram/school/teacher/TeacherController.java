package com.example.demoprogram.school.teacher;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/teachers")
public class TeacherController {

	
	@Autowired
	TeacherService teacherService;
	
	
	@GetMapping
	List<Teacher> getStudents(){
		return teacherService.getAllTeachers();
	}
	
	@PostMapping
	Teacher createTeacher(@RequestBody Teacher teacher) {
		return teacherService.createTeacher(teacher);
	}
	
	@GetMapping("/getAllTeachersbyType/{status}")
	List<Teacher> getAllTeachersByType(@PathVariable String status) {
		return  teacherService.getAllTeachersByStatus(status);
	}
}

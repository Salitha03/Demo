package com.example.demoprogram.school.teacher;

import java.util.List;

public interface TeacherService {

	List<Teacher> getAllTeachers();
	Teacher createTeacher(Teacher teacher);
	List<Teacher> getAllTeachersByStatus(String status);
}

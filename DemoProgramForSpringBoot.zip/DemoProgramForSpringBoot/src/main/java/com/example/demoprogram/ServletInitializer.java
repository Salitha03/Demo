package com.example.demoprogram;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.builder.SpringApplicationBuilder;
import org.springframework.boot.web.servlet.support.SpringBootServletInitializer;
import org.springframework.web.WebApplicationInitializer;

public class ServletInitializer extends SpringBootServletInitializer implements WebApplicationInitializer {

	  @Override
		protected SpringApplicationBuilder configure(SpringApplicationBuilder application) {
		  System.out.println("Callig configire");

			return application.sources(DemoprogramForSpringBootApplication.class);
		}
	  
	  
	  public static void main(String[] args) {
		  System.out.println("Callig main");
			SpringApplication.run(DemoprogramForSpringBootApplication.class, args);
		}
}

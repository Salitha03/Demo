package com.example.demoprogram.school.subject;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demoprogram.school.teacher.Teacher;

@RestController
@RequestMapping("/subjects")
public class SubjectController {

	
	@Autowired
	SubjectService subjectService;
	
	@Autowired
	SubjectService teacherService;
	
	
	@GetMapping
	List<Subject> getStudents(){
		return subjectService.getAllSubjects();
	}
	
	@PostMapping
	Subject createStudent(@RequestBody Subject subject) {
		return subjectService.createSubject(subject);
	}
	
	@PutMapping("/{subjectId}/students/{studentId}")
	Subject enrollStudentToSubject(@PathVariable long subjectId, @PathVariable long studentId) {
		return subjectService.enrollStudentToSubject(subjectId,studentId);
	}
	
	
	@PutMapping("/{subjectId}/teachers/{teacherId}")
	void assignTeacherToSubject(@PathVariable long subjectId, @PathVariable long teacherId) {
	  subjectService.assignTeacherToSubject(subjectId,teacherId);
	}
}

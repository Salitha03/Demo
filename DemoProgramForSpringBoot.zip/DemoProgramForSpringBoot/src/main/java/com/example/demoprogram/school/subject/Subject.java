package com.example.demoprogram.school.subject;

import java.util.HashSet;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import com.example.demoprogram.school.student.Student;
import com.example.demoprogram.school.teacher.Teacher;


@Entity
@Table
/**
 * @author Salitha
 * Subject entity 
 * Relationships:
 * 1)  Multiple subjects enroll by many  students. (Many to Many relationship)
 * 2)  Multiple subjects taught by one teacher (Many to One relationship)
 */
public class Subject {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private long id;
	
	private String name;
	public long getId() {
		return id;
	}
	public void setId(long id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	
	//Bidirectional mapping for many students enrolled into many subjects.
	@ManyToMany
	@JoinTable(
			name="student_enrolled_table",
			joinColumns=@JoinColumn(name="subject_id"), //subject_id from subject table
			inverseJoinColumns = @JoinColumn(name="student_id") //student_id from student table.
	)
	private Set<Student> enrolledStudents = new HashSet<>();
	
	public Set<Student> getEnrolledStudents() {
		return enrolledStudents;
	}
	//Added join column at MANY side..
	@ManyToOne(cascade = CascadeType.ALL)
	@JoinColumn(name="teacher_id",referencedColumnName = "id")
	private Teacher teacher;
	public Teacher getTeacher() {
		return teacher;
	}
	public void setTeacher(Teacher teacher) {
		this.teacher = teacher;
	}
	
	
	
	
	
}

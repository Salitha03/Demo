package com.example.demoprogram.school.subject;

import java.util.List;

import com.example.demoprogram.school.teacher.Teacher;

public interface SubjectService {

	List<Subject> getAllSubjects();
	Subject createSubject(Subject subject);
	Subject enrollStudentToSubject(long subjectId, long studentId);
	Subject assignTeacherToSubject(long subjectId, long teacherId);
}
